# Ember Table by Addepar Globals Build

There are some legacy apps which are not in ember-cli or ES6 modules style, and
expect some global objects to exist. The broccoli build in this file generates
those global objects.

## Building

Don't build from this directory. Go to the main directory and run `grunt dist`.
