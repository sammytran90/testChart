export function emberSelectFor(name) {
  return '[data-test="' + name + '"] .ember-select';
}