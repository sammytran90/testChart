export default [{
  group: "Cash",
  xValue: 0,
  yValue: 0
}];