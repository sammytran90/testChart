export default [{
  xValue: 0,
  yValue: 0
}];