export default [{
  group: "Energy",
  xValue: 0.017,
  yValue: 0.03
}, {
  group: "Energy",
  xValue: 0.044,
  yValue: 0.048
}, {
  group: "Energy",
  xValue: 0.005,
  yValue: 0.01,
}, {
  group: "Industrial Metals",
  xValue: -0.28,
  yValue: -0.08
}, {
  group: "Industrial Metals",
  xValue: -0.90,
  yValue: -0.08
}, {
  group: "Industrial Metals",
  xValue: -0.44,
  yValue: -0.16
}, {
  group: "Municipal Bonds",
  xValue: 0.14,
  yValue: 0.04
}, {
  group: "Municipal Bonds",
  xValue: 0.24,
  yValue: 0.83
}, {
  group: "Municipal Bonds",
  xValue: 0.39,
  yValue: 0.48
}, {
  group: "Precious Metals",
  xValue: -0.12,
  yValue: -0.22
}, {
  group: "Precious Metals",
  xValue: -0.09,
  yValue: -0.70
}, {
  group: "Precious Metals",
  xValue: -0.70,
  yValue: -0.88
}, {
  group: "Real Estate",
  xValue: -0.28,
  yValue: -0.91
}, {
  group: "Real Estate",
  xValue: -0.40,
  yValue: -0.71
}, {
  group: "Real Estate",
  xValue: -0.35,
  yValue: -0.17
}, {
  group: "Venture",
  xValue: -0.46,
  yValue: -0.30
}, {
  group: "Venture",
  xValue: -0.65,
  yValue: -0.92
}, {
  group: "Venture",
  xValue: -0.37,
  yValue: -0.30
}];
