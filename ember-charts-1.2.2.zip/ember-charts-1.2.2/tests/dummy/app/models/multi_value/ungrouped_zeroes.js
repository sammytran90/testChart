export default [{
  xValue: 0,
  yValue: 0
}, {
  xValue: 0,
  yValue: 0
}, {
  xValue: 0,
  yValue: 0
}, {
  xValue: 0,
  yValue: 0
}, {
  xValue: 0,
  yValue: 0
}, {
  xValue: 0,
  yValue: 0
}];