export default [{
  group: "Energy",
  xValue: 0,
  yValue: 0
}, {
  group: "Industrial Metals",
  xValue: 0,
  yValue: 0
}, {
  group: "Municipal Bonds",
  xValue: 0,
  yValue: 0
}, {
  group: "Precious Metals",
  xValue: 0,
  yValue: 0
}, {
  group: "Real Estate",
  xValue: 0,
  yValue: 0
}, {
  group: "Venture",
  xValue: 0,
  yValue: 0
}];