export default [{
    label: "Cash & Cash Equivalent",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 5403418.115000006,
    type: "money"
  }, {
    label: "Fixed Income",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 8231078.16438347,
    type: "money"
  }, {
    label: "Equity",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 12935781.176999997,
    type: "money"
  }, {
    label: "Hedge Fund",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 1621341.246006786,
    type: "money"
  }, {
    label: "Private Equity",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 1574677.59,
    type: "money"
  }, {
    label: "Real Assets",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 10475849.276172025,
    type: "money"
  }, {
    label: "Other",
    group: "Bank of America Merrill Lynch Global High Yield Index",
    value: 10475849.276172025,
    type: "money"
  }, {
    label: "Cash & Cash Equivalent",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 1933418.115000006,
    type: "money"
  }, {
    label: "Fixed Income",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 1031078.16438347,
    type: "money"
  }, {
    label: "Equity",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 14235781.176999997,
    type: "money"
  }, {
    label: "Hedge Fund",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 3981341.246006786,
    type: "money"
  }, {
    label: "Private Equity",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 6644677.59,
    type: "money"
  }, {
    label: "Real Assets",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 17513849.276172025,
    type: "money"
  }, {
    label: "Other",
    group: "S&P Goldman Sachs Commodity Total Return Index",
    value: 4758493.276172025,
    type: "money"
}];