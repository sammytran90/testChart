export default [{
    label: "Label 1",
    group: "Group One",
    value: 20
}, {
    label: "Label 1",
    group: "Group Two",
    value: 32
}, {
    label: "Label 1",
    group: "Group Three",
    value: 4
}, {
    label: "Label 2",
    group: "Group One",
    value: 16
}, {
    label: "Label 2",
    group: "Group Two",
    value: 17
}, {
    label: "Label 2",
    group: "Group Three",
    value: -18
}, {
    label: "Label 3",
    group: "Group One",
    value: -18
}, {
    label: "Label 3",
    group: "Group Two",
    value: 18
}, {
    label: "Label 3",
    group: "Group Three",
    value: -19
}];