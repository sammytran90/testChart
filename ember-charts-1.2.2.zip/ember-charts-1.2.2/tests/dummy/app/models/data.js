export default {
	null: null,
	empty: []
};
