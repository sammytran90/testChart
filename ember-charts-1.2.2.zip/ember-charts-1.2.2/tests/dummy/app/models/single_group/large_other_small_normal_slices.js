export default [{
    label: "Label 1",
    value: 4.2
  }, {
    label: "Label 2",
    value: 4.325
  }, {
    label: "Label 3",
    value: 3.2
  }, {
    label: "Label 4",
    value: 2.9223
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 10",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 20",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 10",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 20",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 10",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 20",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 10",
    value: 2
  }, {
    label: "Label 5",
    value: 2
  }, {
    label: "Label 6",
    value: 2
  }, {
    label: "Label 8",
    value: 2
  }, {
    label: "Label 9",
    value: 2
  }, {
    label: "Label 20",
    value: 2
  }];
