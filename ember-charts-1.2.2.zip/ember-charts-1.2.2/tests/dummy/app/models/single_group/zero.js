export default [{
    label: "Label 1",
    value: 0,
    type: "percent"
}];
  