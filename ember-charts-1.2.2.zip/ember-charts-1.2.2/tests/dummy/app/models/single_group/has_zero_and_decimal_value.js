export default [{
    label: "Label 1",
    value: 300
  }, {
    label: "Label 2",
    value: 20
  }, {
    label: "Label 3",
    value: 20
  }, {
    label: "Label 4",
    value: 20
  }, {
    label: "Label 5",
    value: 20
  }, {
    label: "Label 6",
    value: 6
  }, {
    label: "Label 8",
    value: 0.223
  }, {
    label: "Label 9",
    value: 0.115
  }, {
    label: "Label 10",
    value: 0
  }];
