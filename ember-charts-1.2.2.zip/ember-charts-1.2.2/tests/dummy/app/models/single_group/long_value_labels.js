export default [{
    label: "Label 1",
    value: 1230981230,
    type: "percent"
  }, {
    label: "Label 2",
    value: 20912312,
    type: "percent"
  }, {
    label: "Label 3",
    value: 3212123,
    type: "percent"
  }, {
    label: "Label 4",
    value: -512019283,
    type: "percent"
  }, {
    label: "Label 5",
    value: 0,
    type: "percent"
  }, {
    label: "Label 6",
    value: -120938123,
    type: "percent"
}];
