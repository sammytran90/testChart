export default [{
    label: "Label 1",
    value: 94
  }, {
    label: "Label 2",
    value: 3
  }, {
    label: "Label 3",
    value: 3
}];
