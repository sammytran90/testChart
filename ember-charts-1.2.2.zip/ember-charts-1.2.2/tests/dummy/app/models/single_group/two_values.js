export default [{
    label: "Label 1",
    value: 20
  }, {
    label: "Label 2",
    value: -1
}];