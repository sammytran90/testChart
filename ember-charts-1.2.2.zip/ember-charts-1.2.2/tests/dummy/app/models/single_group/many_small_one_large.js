export default [{
    label: "Label 1",
    value: 255
  }, {
    label: "Label 2",
    value: 5
  }, {
    label: "Label 3",
    value: 5
  }, {
    label: "Label 4",
    value: 5
  }, {
    label: "Label 5",
    value: 5
  }, {
    label: "Label 6",
    value: 5
  }, {
    label: "Label 7",
    value: 5
  }, {
    label: "Label 8",
    value: 5
  }, {
    label: "Label 9",
    value: 5
  }, {
    label: "Label 10",
    value: 5
  }, {
    label: "Label 11",
    value: 5
  }, {
    label: "Label 12",
    value: 5
  }, {
    label: "Label 13",
    value: 5
  }, {
    label: "Label 14",
    value: 5
  }, {
    label: "Label 15",
    value: 5
  }];
