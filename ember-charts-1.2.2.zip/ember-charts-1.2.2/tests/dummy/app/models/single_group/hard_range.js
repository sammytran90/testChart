export default [{
    label: "Label 1",
    value: 50
  }, {
    label: "Label 2",
    value: 29
  }, {
    label: "Label 3",
    value: 14
  }, {
    label: "Label 4",
    value: 3.1
  }, {
    label: "Label 5",
    value: 3.1
  }, {
    label: "Label 6",
    value: 3.1
  }];
