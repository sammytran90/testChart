export default [{
    label: "Label 1",
    value: 0,
    type: "percent"
  }, {
    label: "Label 2",
    value: 0,
    type: "percent"
  }, {
    label: "Label 3",
    value: 0,
    type: "percent"
  }, {
    label: "Label 4",
    value: 0,
    type: "percent"
  }, {
    label: "Label 5",
    value: 0,
    type: "percent"
  }, {
    label: "Label 6",
    value: 0,
    type: "percent"
}];
  