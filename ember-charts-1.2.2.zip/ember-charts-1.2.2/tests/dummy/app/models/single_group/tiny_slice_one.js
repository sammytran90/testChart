export default [{
    label: "Label 1",
    value: 25.3,
    type: "percent"
  }, {
    label: "Label 2",
    value: 74.4,
    type: "percent"
  }, {
    label: "Label 3",
    value: 0.3,
    type: "percent"
}];
