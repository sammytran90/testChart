export default [{
    label: "Label 1 - There is a long grouping label on the left",
    value: 1029380192830981012,
    type: "percent"
  }, {
    label: "Label 2 - 10293801928309123",
    value: 12312312312123123,
    type: "percent"
  }, {
    label: "Label 3 - 192083091283123",
    value: 10299380192830911,
    type: "percent"
  }, {
    label: "Label 4 - There is a long grouping lable on the right that should be flush",
    value: -510293809123123123,
    type: "percent"
  }, {
    label: "Label 5",
    value: 0,
    type: "percent"
  }, {
    label: "Label 6",
    value: -123010928301901928,
    type: "percent"
}];
