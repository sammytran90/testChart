export default [{
    label: "Label 1",
    value: 48
  }, {
    label: "Label 2",
    value: 48
  }, {
    label: "Label 3",
    value: 4
  }, {
    label: "Label 4",
    value: 0
  }];

