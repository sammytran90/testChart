export default [{
    label: "Label 1",
    value: 20
}];