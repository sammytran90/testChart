export default [{
    label: "Cash & Cash Equivalent",
    value: 5403418.115000006,
    type: "money",
  }, {
    label: "Fixed Income",
    value: 8231078.16438347,
    type: "money",
  }, {
    label: "Equity",
    value: 12935781.176999997,
    type: "money",
  }, {
    label: "Hedge Fund",
    value: 1621341.246006786,
    type: "money",
  }, {
    label: "Private Equity",
    value: 1574677.59,
    type: "money",
  }, {
    label: "Real Assets",
    value: 10475849.276172025,
    type: "money"
}];
