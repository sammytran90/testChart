export default [{
    label: "Label 1",
    value: 30
  }, {
    label: "Label 2",
    value: 21
  }, {
    label: "Label 3",
    value: 11
  }, {
    label: "Label 4",
    value: 10
  }, {
    label: "Label 5",
    value: 5
  }, {
    label: "Label 6",
    value: 5
  }, {
    label: "Label 7",
    value: 5
  }, {
    label: "Label 8",
    value: 3
  }, {
    label: "Label 9",
    value: 3
}, {
    label: "Label 9",
    value: 3
}, {
    label: "Label 9",
    value: 3
}, {
    label: "Label 9",
    value: 1
}];
