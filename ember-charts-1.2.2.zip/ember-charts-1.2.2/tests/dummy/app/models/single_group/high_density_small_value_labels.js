export default [{
    label: "Label 1",
    value: 40
  }, {
    label: "Label 2",
    value: 20
  }, {
    label: "Label 3",
    value: 20
  }, {
    label: "Label 4",
    value: 20
  }, {
    label: "Label 5",
    value: 20
  }, {
    label: "Label 6",
    value: 6
  }, {
    label: "Label 7",
    value: 0
  }, {
    label: "Label 8",
    value: 0.1
  }, {
    label: "Label 9",
    value: 0.2
  }, {
    label: "Label 10",
    value: 0.3
  }, {
    label: "Label 11",
    value: 0.4
  }];
