export default [{
    label: "Label 1",
    value: 200
  }, {
    label: "Label 2",
    value: 220
  }, {
    label: "Label 3",
    value: 0.1
  }, {
    label: "Label 4",
    value: 1
  }, {
    label: "Label 5",
    value: 1
  }, {
    label: "Label 6",
    value: -18
  }, {
    label: "Label 7",
    value: -18
  }, {
    label: "Label 8",
    value: 18
}];