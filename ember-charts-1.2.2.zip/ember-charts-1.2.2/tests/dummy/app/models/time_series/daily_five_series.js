export default [{
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
    value: 43642.83058384
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
    value: 43682.88915361
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
    value: 44073.26541992
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
    value: 43960.89079724
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
    value: 43830.11730889
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
    value: 43836.09425964
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
    value: 43836.98702062
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
    value: 43810.160309985
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
    value: 43845.01459874
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
    value: 43834.58089744
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
    value: 43946.88897166
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
    value: 44008.05339702
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
    value: 44002.03240921
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
    value: 44002.92517018
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    value: 43883.751494944
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
    value: 43787.478592515
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
    value: 43800.91393495
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
    value: 43847.45659791
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
    value: 43806.06566759
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
    value: 43761.361287594
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
    value: 43760.77428893
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
    value: 43753.75257796
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
    value: 43797.0534512
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
    value: 43903.166108675
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
    value: 43528.911187135
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
    value: 43528.5087995
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
    value: 43536.43765646
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
    value: 43535.151219256
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
    value: 43593.26305722
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
    value: 43605.73629416
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
    value: 43467.68957965
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
    value: 42771.6341555
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
    value: 42952.52450345
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
    value: 42949.3252776
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
    value: 42965.12680685
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
    value: 42788.365361154
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
    value: 42999.018564746
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
    value: 42984.25380657
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
    value: 43092.03838536
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
    value: 43239.54054056
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
    value: 43251.102895156
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
    value: 43266.851351626
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
    value: 43198.25866338
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
    value: 43127.899708465
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
    value: 43092.78262602
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    value: 43059.753658235
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
    value: 43031.82903179
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
    value: 43039.052389316
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
    value: 43028.129793495
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
    value: 42949.12505133
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
    value: 42969.85994651
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
    value: 41166.50141647
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
    value: 40973.68578022
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
    value: 41144.59044995
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
    value: 41103.62357324
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
    value: 41089.28626931
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
    value: 40810.757803045
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
    value: 40960.365781054
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
    value: 40990.341687664
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
    value: 41038.33765783
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
    value: 41123.78119157
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
    value: 41122.26395758
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
    value: 41111.862666905
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
    value: 41105.36785514
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
    value: 41338.68798077
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
    value: 41318.38568769
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
    value: 41288.000519715
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
    value: 41394.8935722
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
    value: 41327.87259761
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
    value: 41389.726178005
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
    value: 41304.35617159
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
    value: 41339.87327992
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
    value: 41494.74761456
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
    value: 41560.61293533
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    value: 41503.2480122
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
    value: 41530.226376854
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
    value: 41497.11765335
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
    value: 41446.59964011
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
    value: 41502.52936411
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
    value: 41524.3780276
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
    value: 41671.35545982
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
    value: 41669.92976583
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
    value: 41720.179477125
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
    value: 41628.44929372
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
    value: 41587.2875385
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
    value: 41523.13958358
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
    value: 41581.906624086
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
    value: 41559.74815625
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
    value: 41587.646175556
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
    value: 41603.58765722
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
    value: 41396.90719793
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
    value: 41383.563815154
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
    value: 41192.78391157
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
    value: 41253.35731214
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
    value: 41317.76603217
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
    value: 41323.089508615
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
    value: 41243.78152139
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
    value: 41291.290488206
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
    value: 41339.92400218
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
    value: 41546.78601642
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
    value: 41603.411002316
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
    value: 41559.51486835
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
    value: 41482.91847159
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
    value: 41480.73691452
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
    value: 41139.44190527
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    value: 41322.227731675
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
    value: 41058.799596176
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
    value: 39228.076058425
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
    value: 39323.23871247
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
    value: 39268.47259191
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
    value: 39253.67428885
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
    value: 39350.86202348
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
    value: 39497.54428209
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
    value: 39529.82300201
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
    value: 39695.87041424
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
    value: 39856.110916235
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
    value: 39904.348645695
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
    value: 39911.55678164
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
    value: 40117.15288461
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
    value: 40302.42957168
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
      value: 40154.01754071,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
      value: 40334.40355735,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
      value: 40417.538894475,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
      value: 40378.92107112,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
      value: 40323.981287375,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
      value: 40406.30461705,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
      value: 40468.537492536,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
      value: 40571.28189174,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
      value: 40486.976005994,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
      value: 40497.55562255,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
      value: 40470.31212439,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
      value: 40452.748340756,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
      value: 40407.250740774,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
      value: 40384.5789883,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
      value: 40339.10700085,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
      value: 40344.09590606,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
      value: 40393.32096114,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
      value: 40398.06808723,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
      value: 40375.67488961,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
      value: 40511.88696648,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
      value: 40458.99458108,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
      value: 40252.87627769,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
      value: 40265.55702015,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
      value: 40224.564452775,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
      value: 40257.45817048,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
      value: 40232.16724148,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
      value: 40212.897360876,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
      value: 40206.02274663,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
      value: 40134.19722524,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
      value: 40249.289020866,
    }, {
      label: 'Group One',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
      value: 40165.45544968,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
      value: 53642.83058384,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
      value: 53682.88915361,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
      value: 54073.26541992,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
      value: 53960.89079724,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
      value: 53830.11730889,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
      value: 53836.09425964,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
      value: 53836.98702062,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
      value: 53810.160309985,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
      value: 53845.01459874,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
      value: 53834.58089744,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
      value: 53946.88897166,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
      value: 54008.05339702,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
      value: 54002.03240921,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
      value: 54002.92517018,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
      value: 53883.751494944,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
      value: 53787.478592515,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
      value: 53800.91393495,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
      value: 53847.45659791,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
      value: 53806.06566759,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
      value: 53761.361287594,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
      value: 53760.77428893,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
      value: 53753.75257796,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
      value: 53797.0534512,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
      value: 53903.166108675,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
      value: 53528.911187135,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
      value: 53528.5087995,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
      value: 53536.43765646,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
      value: 53535.151219256,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
      value: 53593.26305722,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
      value: 53605.73629416,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
      value: 53467.68957965,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
      value: 52771.6341555,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
      value: 52952.52450345,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
      value: 52949.3252776,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
      value: 52965.12680685,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
      value: 52788.365361154,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
      value: 52999.018564746,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
      value: 52984.25380657,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
      value: 53092.03838536,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
      value: 53239.54054056,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
      value: 53251.102895156,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
      value: 53266.851351626,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
      value: 53198.25866338,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
      value: 53127.899708465,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
      value: 53092.78262602,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
      value: 53059.753658235,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
      value: 53031.82903179,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
      value: 53039.052389316,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
      value: 53028.129793495,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
      value: 52949.12505133,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
      value: 52969.85994651,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
      value: 51166.50141647,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
      value: 50973.68578022,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
      value: 51144.59044995,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
      value: 51103.62357324,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
      value: 51089.28626931,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
      value: 50810.757803045,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
      value: 50960.365781054,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
      value: 50990.341687664,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
      value: 51038.33765783,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
      value: 51123.78119157,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
      value: 51122.26395758,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
      value: 51111.862666905,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
      value: 51105.36785514,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
      value: 51338.68798077,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
      value: 51318.38568769,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
      value: 51288.000519715,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
      value: 51394.8935722,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
      value: 51327.87259761,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
      value: 51389.726178005,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
      value: 51304.35617159,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
      value: 51339.87327992,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
      value: 51494.74761456,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
      value: 51560.61293533,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
      value: 51503.2480122,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
      value: 51530.226376854,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
      value: 51497.11765335,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
      value: 51446.59964011,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
      value: 51502.52936411,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
      value: 51524.3780276,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
      value: 51671.35545982,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
      value: 51669.92976583,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
      value: 51720.179477125,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
      value: 51628.44929372,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
      value: 51587.2875385,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
      value: 51523.13958358,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
      value: 51581.906624086,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
      value: 51559.74815625,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
      value: 51587.646175556,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
      value: 51603.58765722,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
      value: 51396.90719793,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
      value: 51383.563815154,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
      value: 51192.78391157,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
      value: 51253.35731214,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
      value: 51317.76603217,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
      value: 51323.089508615,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
      value: 51243.78152139,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
      value: 51291.290488206,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
      value: 51339.92400218,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
      value: 51546.78601642,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
      value: 51603.411002316,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
      value: 51559.51486835,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
      value: 51482.91847159,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
      value: 51480.73691452,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
      value: 51139.44190527,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
      value: 51322.227731675,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
      value: 51058.799596176,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
      value: 49228.076058425,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
      value: 49323.23871247,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
      value: 49268.47259191,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
      value: 49253.67428885,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
      value: 49350.86202348,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
      value: 49497.54428209,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
      value: 49529.82300201,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
      value: 49695.87041424,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
      value: 49856.110916235,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
      value: 49904.348645695,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
      value: 49911.55678164,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
      value: 50117.15288461,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
      value: 50302.42957168,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
      value: 50154.01754071,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
      value: 50334.40355735,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
      value: 50417.538894475,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
      value: 50378.92107112,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
      value: 50323.981287375,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
      value: 50406.30461705,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
      value: 50468.537492536,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
      value: 50571.28189174,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
      value: 50486.976005994,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
      value: 50497.55562255,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
      value: 50470.31212439,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
      value: 50452.748340756,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
      value: 50407.250740774,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
      value: 50384.5789883,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
      value: 50339.10700085,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
      value: 50344.09590606,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
      value: 50393.32096114,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
      value: 50398.06808723,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
      value: 50375.67488961,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
      value: 50511.88696648,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
      value: 50458.99458108,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
      value: 50252.87627769,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
      value: 50265.55702015,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
      value: 50224.564452775,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
      value: 50257.45817048,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
      value: 50232.16724148,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
      value: 50212.897360876,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
      value: 50206.02274663,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
      value: 50134.19722524,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
      value: 50249.289020866,
    }, {
      label: 'Group Two',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
      value: 50165.45544968,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
      value: 63642.83058384,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
      value: 63682.88915361,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
      value: 64073.26541992,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
      value: 63960.89079724,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
      value: 63830.11730889,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
      value: 63836.09425964,
    }, {
  label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
      value: 63836.98702062,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
      value: 63810.160309985,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
      value: 63845.01459874,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
      value: 63834.58089744,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
      value: 63946.88897166,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
      value: 64008.05339702,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
      value: 64002.03240921,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
      value: 64002.92517018,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
      value: 63883.751494944,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
      value: 63787.478592515,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
      value: 63800.91393495,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
      value: 63847.45659791,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
      value: 63806.06566759,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
      value: 63761.361287594,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
      value: 63760.77428893,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
      value: 63753.75257796,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
      value: 63797.0534512,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
      value: 63903.166108675,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
      value: 63528.911187135,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
      value: 63528.5087995,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
      value: 63536.43765646,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
      value: 63535.151219256,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
      value: 63593.26305722,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
      value: 63605.73629416,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
      value: 63467.68957965,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
      value: 62771.6341555,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
      value: 62952.52450345,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
      value: 62949.3252776,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
      value: 62965.12680685,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
      value: 62788.365361154,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
      value: 62999.018564746,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
      value: 62984.25380657,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
      value: 63092.03838536,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
      value: 63239.54054056,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
      value: 63251.102895156,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
      value: 63266.851351626,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
      value: 63198.25866338,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
      value: 63127.899708465,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
      value: 63092.78262602,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
      value: 63059.753658235,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
      value: 63031.82903179,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
      value: 63039.052389316,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
      value: 63028.129793495,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
      value: 62949.12505133,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
      value: 62969.85994651,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
      value: 61166.50141647,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
      value: 60973.68578022,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
      value: 61144.59044995,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
      value: 61103.62357324,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
      value: 61089.28626931,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
      value: 60810.757803045,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
      value: 60960.365781054,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
      value: 60990.341687664,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
      value: 61038.33765783,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
      value: 61123.78119157,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
      value: 61122.26395758,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
      value: 61111.862666905,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
      value: 61105.36785514,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
      value: 61338.68798077,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
      value: 61318.38568769,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
      value: 61288.000519715,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
      value: 61394.8935722,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
      value: 61327.87259761,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
      value: 61389.726178005,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
      value: 61304.35617159,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
      value: 61339.87327992,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
      value: 61494.74761456,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
      value: 61560.61293533,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
      value: 61503.2480122,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
      value: 61530.226376854,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
      value: 61497.11765335,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
      value: 61446.59964011,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
      value: 61502.52936411,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
      value: 61524.3780276,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
      value: 61671.35545982,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
      value: 61669.92976583,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
      value: 61720.179477125,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
      value: 61628.44929372,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
      value: 61587.2875385,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
      value: 61523.13958358,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
      value: 61581.906624086,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
      value: 61559.74815625,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
      value: 61587.646175556,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
      value: 61603.58765722,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
      value: 61396.90719793,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
      value: 61383.563815154,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
      value: 61192.78391157,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
      value: 61253.35731214,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
      value: 61317.76603217,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
      value: 61323.089508615,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
      value: 61243.78152139,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
      value: 61291.290488206,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
      value: 61339.92400218,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
      value: 61546.78601642,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
      value: 61603.411002316,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
      value: 61559.51486835,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
      value: 61482.91847159,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
      value: 61480.73691452,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
      value: 61139.44190527,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
      value: 61322.227731675,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
      value: 61058.799596176,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
      value: 59228.076058425,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
      value: 59323.23871247,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
      value: 59268.47259191,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
      value: 59253.67428885,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
      value: 59350.86202348,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
      value: 59497.54428209,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
      value: 59529.82300201,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
      value: 59695.87041424,
    }, {
  label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
      value: 59856.110916235,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
      value: 59904.348645695,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
      value: 59911.55678164,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
      value: 60117.15288461,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
      value: 60302.42957168,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
      value: 60154.01754071,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
      value: 60334.40355735,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
      value: 60417.538894475,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
      value: 60378.92107112,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
      value: 60323.981287375,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
      value: 60406.30461705,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
      value: 60468.537492536,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
      value: 60571.28189174,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
      value: 60486.976005994,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
      value: 60497.55562255,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
      value: 60470.31212439,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
      value: 60452.748340756,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
      value: 60407.250740774,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
      value: 60384.5789883,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
      value: 60339.10700085,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
      value: 60344.09590606,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
      value: 60393.32096114,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
      value: 60398.06808723,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
      value: 60375.67488961,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
      value: 60511.88696648,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
      value: 60458.99458108,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
      value: 60252.87627769,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
      value: 60265.55702015,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
      value: 60224.564452775,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
      value: 60257.45817048,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
      value: 60232.16724148,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
      value: 60212.897360876,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
      value: 60206.02274663,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
      value: 60134.19722524,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
      value: 60249.289020866,
    }, {
      label: 'Group Three',
      time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
      value: 60165.45544968,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
      value: 73642.83058384,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
      value: 73682.88915361,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
      value: 74073.26541992,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
      value: 73960.89079724,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
      value: 73830.11730889,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
      value: 73836.09425964,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
      value: 73836.98702062,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
      value: 73810.160309985,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
      value: 73845.01459874,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
      value: 73834.58089744,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
      value: 73946.88897166,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
      value: 74008.05339702,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
      value: 74002.03240921,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
      value: 74002.92517018,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
      value: 73883.751494944,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
      value: 73787.478592515,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
      value: 73800.91393495,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
      value: 73847.45659791,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
      value: 73806.06566759,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
      value: 73761.361287594,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
      value: 73760.77428893,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
      value: 73753.75257796,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
      value: 73797.0534512,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
      value: 73903.166108675,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
      value: 73528.911187135,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
      value: 73528.5087995,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
      value: 73536.43765646,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
      value: 73535.151219256,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
      value: 73593.26305722,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
      value: 73605.73629416,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
      value: 73467.68957965,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
      value: 72771.6341555,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
      value: 72952.52450345,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
      value: 72949.3252776,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
      value: 72965.12680685,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
      value: 72788.365361154,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
      value: 72999.018564746,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
      value: 72984.25380657,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
      value: 73092.03838536,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
      value: 73239.54054056,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
      value: 73251.102895156,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
      value: 73266.851351626,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
      value: 73198.25866338,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
      value: 73127.899708465,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
      value: 73092.78262602,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
      value: 73059.753658235,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
      value: 73031.82903179,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
      value: 73039.052389316,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
      value: 73028.129793495,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
      value: 72949.12505133,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
      value: 72969.85994651,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
      value: 71166.50141647,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
      value: 70973.68578022,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
      value: 71144.59044995,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
      value: 71103.62357324,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
      value: 71089.28626931,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
      value: 70810.757803045,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
      value: 70960.365781054,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
      value: 70990.341687664,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
      value: 71038.33765783,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
      value: 71123.78119157,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
      value: 71122.26395758,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
      value: 71111.862666905,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
      value: 71105.36785514,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
      value: 71338.68798077,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
      value: 71318.38568769,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
      value: 71288.000519715,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
      value: 71394.8935722,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
      value: 71327.87259761,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
      value: 71389.726178005,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
      value: 71304.35617159,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
      value: 71339.87327992,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
      value: 71494.74761456,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
      value: 71560.61293533,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
      value: 71503.2480122,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
      value: 71530.226376854,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
      value: 71497.11765335,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
      value: 71446.59964011,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
      value: 71502.52936411,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
      value: 71524.3780276,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
      value: 71671.35545982,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
      value: 71669.92976583,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
      value: 71720.179477125,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
      value: 71628.44929372,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
      value: 71587.2875385,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
      value: 71523.13958358,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
      value: 71581.906624086,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
      value: 71559.74815625,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
      value: 71587.646175556,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
      value: 71603.58765722,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
      value: 71396.90719793,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
      value: 71383.563815154,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
      value: 71192.78391157,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
      value: 71253.35731214,
    }, {
      label: 'Group Four',
      time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
        value: 71317.76603217,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
        value: 71323.089508615,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
        value: 71243.78152139,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
        value: 71291.290488206,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
        value: 71339.92400218,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
        value: 71546.78601642,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
        value: 71603.411002316,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
        value: 71559.51486835,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
        value: 71482.91847159,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
        value: 71480.73691452,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
        value: 71139.44190527,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
        value: 71322.227731675,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
        value: 71058.799596176,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
        value: 69228.076058425,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
        value: 69323.23871247,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
        value: 69268.47259191,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
        value: 69253.67428885,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
        value: 69350.86202348,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
        value: 69497.54428209,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
        value: 69529.82300201,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
        value: 69695.87041424,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
        value: 69856.110916235,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
        value: 69904.348645695,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
        value: 69911.55678164,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
        value: 70117.15288461,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
        value: 70302.42957168,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
        value: 70154.01754071,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
        value: 70334.40355735,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
        value: 70417.538894475,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
        value: 70378.92107112,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
        value: 70323.981287375,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
        value: 70406.30461705,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
        value: 70468.537492536,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
        value: 70571.28189174,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
        value: 70486.976005994,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
        value: 70497.55562255,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
        value: 70470.31212439,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
        value: 70452.748340756,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
        value: 70407.250740774,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
        value: 70384.5789883,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
        value: 70339.10700085,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
        value: 70344.09590606,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
        value: 70393.32096114,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
        value: 70398.06808723,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
        value: 70375.67488961,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
        value: 70511.88696648,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
        value: 70458.99458108,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
        value: 70252.87627769,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
        value: 70265.55702015,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
        value: 70224.564452775,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
        value: 70257.45817048,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
        value: 70232.16724148,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
        value: 70212.897360876,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
        value: 70206.02274663,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
        value: 70134.19722524,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
        value: 70249.289020866,
      }, {
        label: 'Group Four',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
        value: 70165.45544968,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
        value: 83642.83058384,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
        value: 83682.88915361,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
        value: 84073.26541992,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
        value: 83960.89079724,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
        value: 83830.11730889,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
        value: 83836.09425964,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
        value: 83836.98702062,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
        value: 83810.160309985,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
        value: 83845.01459874,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
        value: 83834.58089744,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
        value: 83946.88897166,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
        value: 84008.05339702,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
        value: 84002.03240921,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
        value: 84002.92517018,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
        value: 83883.751494944,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
        value: 83787.478592515,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
        value: 83800.91393495,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
        value: 83847.45659791,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
        value: 83806.06566759,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
        value: 83761.361287594,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
        value: 83760.77428893,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
        value: 83753.75257796,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
        value: 83797.0534512,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
        value: 83903.166108675,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
        value: 83528.911187135,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
        value: 83528.5087995,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
        value: 83536.43765646,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
        value: 83535.151219256,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
        value: 83593.26305722,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
        value: 83605.73629416,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
        value: 83467.68957965,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
        value: 82771.6341555,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
        value: 82952.52450345,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
        value: 82949.3252776,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
        value: 82965.12680685,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
        value: 82788.365361154,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
        value: 82999.018564746,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
        value: 82984.25380657,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
        value: 83092.03838536,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
        value: 83239.54054056,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
        value: 83251.102895156,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
        value: 83266.851351626,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
        value: 83198.25866338,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
        value: 83127.899708465,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
        value: 83092.78262602,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
        value: 83059.753658235,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
        value: 83031.82903179,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
        value: 83039.052389316,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
        value: 83028.129793495,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
        value: 82949.12505133,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
        value: 82969.85994651,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
        value: 81166.50141647,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
        value: 80973.68578022,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
        value: 81144.59044995,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
        value: 81103.62357324,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
        value: 81089.28626931,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
        value: 80810.757803045,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
        value: 80960.365781054,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
        value: 80990.341687664,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
        value: 81038.33765783,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
        value: 81123.78119157,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
        value: 81122.26395758,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
        value: 81111.862666905,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
        value: 81105.36785514,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
        value: 81338.68798077,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
        value: 81318.38568769,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
        value: 81288.000519715,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
        value: 81394.8935722,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
        value: 81327.87259761,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
        value: 81389.726178005,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
        value: 81304.35617159,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
        value: 81339.87327992,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
        value: 81494.74761456,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
        value: 81560.61293533,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
        value: 81503.2480122,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
        value: 81530.226376854,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
        value: 81497.11765335,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
        value: 81446.59964011,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
        value: 81502.52936411,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
        value: 81524.3780276,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
        value: 81671.35545982,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
        value: 81669.92976583,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
        value: 81720.179477125,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
        value: 81628.44929372,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
        value: 81587.2875385,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
        value: 81523.13958358,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
        value: 81581.906624086,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
        value: 81559.74815625,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
        value: 81587.646175556,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
        value: 81603.58765722,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
        value: 81396.90719793,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
        value: 81383.563815154,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
        value: 81192.78391157,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
        value: 81253.35731214,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
        value: 81317.76603217,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
        value: 81323.089508615,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
        value: 81243.78152139,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
        value: 81291.290488206,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
        value: 81339.92400218,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
        value: 81546.78601642,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
        value: 81603.411002316,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
        value: 81559.51486835,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
        value: 81482.91847159,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
        value: 81480.73691452,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
        value: 81139.44190527,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
        value: 81322.227731675,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
        value: 81058.799596176,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
        value: 79228.076058425,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
        value: 79323.23871247,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
        value: 79268.47259191,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
        value: 79253.67428885,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
        value: 79350.86202348,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
        value: 79497.54428209,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
        value: 79529.82300201,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
        value: 79695.87041424,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
        value: 79856.110916235,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
        value: 79904.348645695,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
        value: 79911.55678164,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
        value: 80117.15288461,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
        value: 80302.42957168,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
        value: 80154.01754071,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
        value: 80334.40355735,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
        value: 80417.538894475,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
        value: 80378.92107112,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
        value: 80323.981287375,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
        value: 80406.30461705,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
        value: 80468.537492536,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
        value: 80571.28189174,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
        value: 80486.976005994,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
        value: 80497.55562255,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
        value: 80470.31212439,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
        value: 80452.748340756,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
        value: 80407.250740774,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
        value: 80384.5789883,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
        value: 80339.10700085,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
        value: 80344.09590606,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
        value: 80393.32096114,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
        value: 80398.06808723,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
        value: 80375.67488961,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
        value: 80511.88696648,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
        value: 80458.99458108,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
        value: 80252.87627769,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
        value: 80265.55702015,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
        value: 80224.564452775,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
        value: 80257.45817048,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
        value: 80232.16724148,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
        value: 80212.897360876,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
        value: 80206.02274663,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
        value: 80134.19722524,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
        value: 80249.289020866,
      }, {
        label: 'Group Five',
        time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
        value: 80165.45544968
      }];
