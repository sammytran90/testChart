export default [{
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Financial analytics software",
    value: 49668,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Financial analytics software",
    value: 68344,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Financial analytics software",
    value: 60654,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Financial analytics software",
    value: 48240,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Financial analytics software",
    value: 62074,
    type: "money"
}];
