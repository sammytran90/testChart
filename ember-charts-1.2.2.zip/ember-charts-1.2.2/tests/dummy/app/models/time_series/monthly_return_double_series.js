export default [{
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Software & Programming",
    value: 17326,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Telecommunication",
    value: 4515,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Software & Programming",
    value: 15326,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Telecommunication",
    value: 1515,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Software & Programming",
    value: 14326,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Telecommunication",
    value: 8518,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Software & Programming",
    value: 42301,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Telecommunication",
    value: 90191,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Software & Programming",
    value: 57326,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Telecommunication",
    value: 39544,
    type: "money"
}];
