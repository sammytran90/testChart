export default [{
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
    value: 0.1
  }, {
    label: 'Group One',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-01"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-02"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-03"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-04"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-05"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-06"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-07"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-08"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-09"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-10"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-11"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-12"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-13"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-14"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-16"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-17"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-18"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-19"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-20"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-21"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-22"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-23"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-24"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-25"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-26"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-27"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-28"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-29"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-30"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-05-31"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-01"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-02"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-03"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-04"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-05"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-06"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-07"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-08"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-09"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-10"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-11"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-12"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-13"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-14"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-16"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-17"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-18"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-19"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-20"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-21"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-22"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-23"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-24"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-25"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-26"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-27"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-06-28"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-01"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-02"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-03"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-04"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-05"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-06"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-07"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-08"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-09"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-10"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-11"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-12"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-13"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-14"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-15"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-17"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-18"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-19"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-20"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-21"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-22"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-23"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-24"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-25"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-26"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-27"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-28"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-29"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-30"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-07-31"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-01"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-02"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-03"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-04"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-05"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-06"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-07"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-08"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-09"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-10"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-11"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-12"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-13"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-14"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-15"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-17"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-18"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-19"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-20"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-21"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-22"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-23"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-24"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-25"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-26"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-27"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-28"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-29"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-08-30"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-01"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-02"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-03"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-04"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-05"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-06"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-07"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-08"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-09"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-10"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-11"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-12"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-13"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-14"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-15"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-17"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-18"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-19"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-20"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-21"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-22"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-23"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-24"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-25"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-26"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-27"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-28"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-29"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-30"),
    value: 0.1
  }, {
    label: 'Group Two',
    time: d3.time.format('%Y-%m-%d').parse("2013-09-31"),
    value: 0.1
}];
