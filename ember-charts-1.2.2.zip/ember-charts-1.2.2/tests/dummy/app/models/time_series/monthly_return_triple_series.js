export default [{
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Software & Programming",
    value: 63540,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Telecommunication",
    value: 31005,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-05-15"),
    label: "Financial analytics software",
    value: 69669,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Software & Programming",
    value: 74860,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Telecommunication",
    value: 14513,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-06-15"),
    label: "Financial analytics software",
    value: 68344,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Software & Programming",
    value: 65435,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Telecommunication",
    value: 40913,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-07-16"),
    label: "Financial analytics software",
    value: 60659,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Software & Programming",
    value: 50241,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Telecommunication",
    value: 30441,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-08-16"),
    label: "Financial analytics software",
    value: 48244,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Software & Programming",
    value: 67326,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Telecommunication",
    value: 17778,
    type: "money"
  }, {
    time: d3.time.format('%Y-%m-%d').parse("2013-09-16"),
    label: "Financial analytics software",
    value: 62079,
    type: "money"
}];
