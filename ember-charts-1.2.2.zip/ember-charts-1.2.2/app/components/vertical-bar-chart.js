import VerticalBarChartComponent from 'ember-charts/components/vertical-bar-chart';
export default VerticalBarChartComponent;