import StackedVerticalBarChartComponent from 'ember-charts/components/stacked-vertical-bar-chart';
export default StackedVerticalBarChartComponent;
