import BubbleChartComponent from 'ember-charts/components/bubble-chart';
export default BubbleChartComponent;