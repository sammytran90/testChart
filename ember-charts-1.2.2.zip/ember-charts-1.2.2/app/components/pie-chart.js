import PieChartComponent from 'ember-charts/components/pie-chart';
export default PieChartComponent;