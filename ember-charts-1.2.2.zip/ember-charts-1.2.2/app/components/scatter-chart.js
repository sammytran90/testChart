import ScatterChartComponent from 'ember-charts/components/scatter-chart';
export default ScatterChartComponent;