import TimeSeriesChartComponent from 'ember-charts/components/time-series-chart';
export default TimeSeriesChartComponent;