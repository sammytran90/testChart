import HorizontalBarChartComponent from 'ember-charts/components/horizontal-bar-chart';
export default HorizontalBarChartComponent;