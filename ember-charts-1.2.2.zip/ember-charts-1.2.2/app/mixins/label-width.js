import LabelWidthMixin from 'ember-charts/mixins/label-width';
export default LabelWidthMixin;
