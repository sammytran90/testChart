import AxisTitles from 'ember-charts/mixins/axis-titles';
export default AxisTitles;
