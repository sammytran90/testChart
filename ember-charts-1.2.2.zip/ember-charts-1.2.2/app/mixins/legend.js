import Legend from 'ember-charts/mixins/legend';
export default Legend;
